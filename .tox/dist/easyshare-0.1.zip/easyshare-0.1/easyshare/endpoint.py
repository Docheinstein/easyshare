from typing import Tuple

Endpoint = Tuple[str, int] # address, port