# (ip, port)
from typing import Tuple

Endpoint = Tuple[str, int]
