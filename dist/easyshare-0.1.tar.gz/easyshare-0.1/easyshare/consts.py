# Python should define these somewhere...
PORT_ANY = 0
ADDR_ANY = ""
ADDR_BROADCAST = "<broadcast>"


G = 1000000000
M = 1000000
K = 1000


STDIN = 0
STDOUT = 1
STDERR = 2