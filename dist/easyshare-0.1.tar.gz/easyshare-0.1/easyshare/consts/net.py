PORT_ANY = 0
ADDR_ANY = ""
ADDR_BROADCAST = "<broadcast>"
