from enum import Enum


class OverwritePolicy:
    PROMPT = 0
    YES = 1
    NO = 2
    NEWER = 3
