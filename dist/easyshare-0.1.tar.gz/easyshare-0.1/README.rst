Easyshare
====

REQUIREMENTS
------------

Requires at least Python 3.5.

INSTALLATION
------------


USAGE
-----

TESTING
-------


LICENSE
-------

Easyshare is `MIT licensed <./LICENSE>`__.
